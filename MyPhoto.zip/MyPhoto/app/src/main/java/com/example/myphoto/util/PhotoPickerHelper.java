package com.example.myphoto.util;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import com.example.myphoto.model.Photo;
import java.util.ArrayList;
import java.util.List;

public class PhotoPickerHelper {

    // 获取手机中的所有图片
    public static List<Photo> getAllPhotos(Context context) {
        List<Photo> photos = new ArrayList<>();
        ContentResolver resolver = context.getContentResolver();
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media.DATA, // 图片路径
                MediaStore.Images.Media.DATE_ADDED // 添加时间
        };

        // 按添加时间倒序查询
        Cursor cursor = resolver.query(
                uri,
                projection,
                null,
                null,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                photos.add(new Photo(path));
            }
            cursor.close();
        }
        return photos;
    }
}