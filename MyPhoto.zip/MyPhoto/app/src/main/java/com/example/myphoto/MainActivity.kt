// MainActivity.java (转换为Java)
package com.example.myphoto

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myphoto.data.DataManager
import com.example.myphoto.model.Album
import com.example.myphoto.ui.AlbumAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private var recyclerView: RecyclerView? = null
    private var adapter: AlbumAdapter? = null
    private var albums: MutableList<Album?>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // 加载数据
        DataManager.getInstance().loadData(this)
        albums = DataManager.getInstance().getAlbums()


        // 初始化RecyclerView
        recyclerView = findViewById(R.id.album_recycler_view)
        recyclerView!!.setLayoutManager(LinearLayoutManager(this))
        adapter = AlbumAdapter(albums, this)
        recyclerView!!.setAdapter(adapter)


        // 添加相册按钮
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener({ v -> showAddAlbumDialog() })
    }

    private fun showAddAlbumDialog() {
        // 实现添加相册的对话框
        // 这里可以使用AlertDialog来获取用户输入的相册名称
    }

    override fun onPause() {
        super.onPause()
        // 保存数据
        DataManager.getInstance().saveData(this)
    }
}