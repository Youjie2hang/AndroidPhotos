// Photo.java
package com.example.myphoto.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Photo implements Serializable {
    private String path; // 图片文件路径
    private List<Tag> tags;

    public Photo(String path) {
        this.path = path;
        this.tags = new ArrayList<>();
    }

    // Getters and setters
    public String getPath() { return path; }
    public List<Tag> getTags() { return tags; }
    
    public void addTag(Tag tag) { tags.add(tag); }
    public void removeTag(Tag tag) { tags.remove(tag); }
    public boolean hasTag(Tag tag) { return tags.contains(tag); }
}