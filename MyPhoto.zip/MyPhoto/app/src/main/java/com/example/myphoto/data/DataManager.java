// DataManager.java
package com.example.myphoto.data;

import android.content.Context;
import com.example.myphoto.model.Album;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static final String DATA_FILE = "photos_data.ser";
    private List<Album> albums;
    private static DataManager instance;

    private DataManager() {
        albums = new ArrayList<>();
    }

    public static synchronized DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }

    // 从文件加载数据
    public void loadData(Context context) {
        try {
            FileInputStream fis = context.openFileInput(DATA_FILE);
            ObjectInputStream ois = new ObjectInputStream(fis);
            albums = (List<Album>) ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            // 如果没有数据文件，使用空列表
            albums = new ArrayList<>();
        }
    }

    // 保存数据到文件
    public void saveData(Context context) {
        try {
            FileOutputStream fos = context.openFileOutput(DATA_FILE, Context.MODE_PRIVATE);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(albums);
            oos.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 相册相关操作
    public List<Album> getAlbums() { return albums; }
    
    public void addAlbum(Album album) { 
        albums.add(album); 
    }
    
    public void deleteAlbum(Album album) { 
        albums.remove(album); 
    }
    
    public boolean renameAlbum(Album album, String newName) {
        for (Album a : albums) {
            if (a.getName().equals(newName)) {
                return false; // 名称已存在
            }
        }
        album.setName(newName);
        return true;
    }
}