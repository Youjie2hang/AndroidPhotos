package com.example.myphoto.util;

import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class PermissionHelper {
    public static final int REQUEST_IMAGE_PERMISSION = 1001;

    // 检查并请求图片权限
    public static boolean checkAndRequestImagePermission(Activity activity) {
        List<String> permissions = new ArrayList<>();
        
        // 检查Android 13+的媒体权限
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(activity, 
                    android.Manifest.permission.READ_MEDIA_IMAGES) 
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(android.Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            // 旧版本权限
            if (ContextCompat.checkSelfPermission(activity, 
                    android.Manifest.permission.READ_EXTERNAL_STORAGE) 
                    != PackageManager.PERMISSION_GRANTED) {
                permissions.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(activity, 
                    permissions.toArray(new String[0]), 
                    REQUEST_IMAGE_PERMISSION);
            return false;
        }
        return true;
    }

    // 检查权限是否全部授予
    public static boolean isAllPermissionsGranted(int[] grantResults) {
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
}