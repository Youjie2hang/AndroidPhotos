package com.example.myphoto;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myphoto.data.DataManager;
import com.example.myphoto.databinding.FragmentFirstBinding;
import com.example.myphoto.model.Album;
import com.example.myphoto.ui.AlbumAdapter;

public class FirstFragment extends Fragment implements AlbumAdapter.OnAlbumClickListener {

    private FragmentFirstBinding binding;
    private AlbumAdapter albumAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 初始化RecyclerView
        RecyclerView recyclerView = binding.albumRecyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        albumAdapter = new AlbumAdapter(DataManager.getInstance().getAlbums(), this);
        recyclerView.setAdapter(albumAdapter);

        // 加载数据
        DataManager.getInstance().loadData(getContext());
        albumAdapter.notifyDataSetChanged();

        // 添加相册按钮点击事件
        binding.fabAddAlbum.setOnClickListener(v -> showAddAlbumDialog());
    }

    // 显示添加相册对话框
    private void showAddAlbumDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("新建相册");

        EditText input = new EditText(getContext());
        builder.setView(input);

        builder.setPositiveButton("确定", (dialog, which) -> {
            String albumName = input.getText().toString().trim();
            if (!albumName.isEmpty()) {
                Album newAlbum = new Album(albumName);
                if (DataManager.getInstance().addAlbum(newAlbum)) {
                    albumAdapter.notifyDataSetChanged();
                    DataManager.getInstance().saveData(getContext());
                } else {
                    Toast.makeText(getContext(), "相册名称已存在", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "名称不能为空", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    @Override
    public void onAlbumClick(Album album) {
        // 点击相册进入详情页（后续实现）
        Toast.makeText(getContext(), "打开相册: " + album.getName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAlbumLongClick(Album album, int position) {
        // 长按相册显示删除/重命名选项（后续实现）
        new AlertDialog.Builder(getContext())
                .setTitle("操作")
                .setItems(new String[]{"重命名", "删除"}, (dialog, which) -> {
                    if (which == 0) {
                        // 重命名逻辑
                    } else if (which == 1) {
                        DataManager.getInstance().deleteAlbum(album);
                        albumAdapter.notifyItemRemoved(position);
                        DataManager.getInstance().saveData(getContext());
                    }
                })
                .show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}