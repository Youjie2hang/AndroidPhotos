// AlbumDetailActivity.java
package com.example.myphoto;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myphoto.model.Album;
import com.example.myphoto.ui.PhotoAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AlbumDetailActivity extends AppCompatActivity {
    public static final String EXTRA_ALBUM_INDEX = "album_index";
    private Album album;
    private int albumIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_detail);
        
        // 获取传递的相册索引
        albumIndex = getIntent().getIntExtra(EXTRA_ALBUM_INDEX, -1);
        if (albumIndex == -1) {
            finish();
            return;
        }
        
        // 获取相册对象
        album = DataManager.getInstance().getAlbums().get(albumIndex);
        setTitle(album.getName());
        
        // 初始化照片网格
        RecyclerView recyclerView = findViewById(R.id.photo_grid);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        PhotoAdapter adapter = new PhotoAdapter(album.getPhotos(), this);
        recyclerView.setAdapter(adapter);
        
        // 添加照片按钮
        FloatingActionButton fab = findViewById(R.id.fab_add_photo);
        fab.setOnClickListener(v -> addPhoto());
    }
    
    private void addPhoto() {
        // 实现从设备添加照片的逻辑
        // 可以使用Intent调用系统相册
    }
}