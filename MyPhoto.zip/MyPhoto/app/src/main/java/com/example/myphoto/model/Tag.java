// Tag.java
package com.example.myphoto.model;

import java.io.Serializable;

public class Tag implements Serializable {
    public enum Type { PERSON, LOCATION }
    
    private Type type;
    private String value;

    public Tag(Type type, String value) {
        this.type = type;
        this.value = value.toLowerCase(); // 存储为小写，方便不区分大小写搜索
    }

    // Getters
    public Type getType() { return type; }
    public String getValue() { return value; }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tag tag = (Tag) o;
        return type == tag.type && value.equals(tag.value);
    }
}