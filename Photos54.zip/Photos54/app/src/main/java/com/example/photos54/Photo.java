package com.example.photos54;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Photo implements Serializable {
    private static final long serialVersionUID = 1L;

    private String filePath;
    private List<Tag> tags;

    public Photo(String filePath) {
        this.filePath = filePath;
        this.tags = new ArrayList<>();
    }

    public String getFilePath() {
        return filePath;
    }

    public List<Tag> getTags() {
        return tags;
    }

    public void addTag(Tag tag) {
        // Prevent duplicate tags
        if (!tags.contains(tag)) {
            tags.add(tag);
        }
    }

    public void removeTag(Tag tag) {
        tags.remove(tag);
    }
}
