package com.example.photos54;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AlbumContentActivity extends AppCompatActivity
        implements PhotosAdapter.OnPhotoClickListener, PhotosAdapter.OnPhotoActionListener {

    private RecyclerView recyclerView;
    private PhotosAdapter adapter;
    private UserData userData;
    private int albumIndex;
    private Album currentAlbum;
    private TextView emptyView;

    // Executor for background tasks (file copying)
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler handler = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String> getContentLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    importPhoto(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_content);

        albumIndex = getIntent().getIntExtra("albumIndex", -1);
        if (albumIndex == -1) {
            finish();
            return;
        }

        userData = PersistenceManager.loadFromDisk(this);
        if (albumIndex >= userData.getAlbums().size()) {
            finish();
            return;
        }
        currentAlbum = userData.getAlbums().get(albumIndex);
        setTitle(currentAlbum.getName());

        recyclerView = findViewById(R.id.recyclerViewPhotos);
        emptyView = findViewById(R.id.textViewEmptyAlbum);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 3)); // 3 columns
        adapter = new PhotosAdapter(currentAlbum.getPhotos(), this, this);
        recyclerView.setAdapter(adapter);

        updateEmptyView();

        FloatingActionButton fab = findViewById(R.id.fabAddPhoto);
        fab.setOnClickListener(v -> getContentLauncher.launch("image/*"));
    }

    private void updateEmptyView() {
        if (currentAlbum.getPhotos().isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void importPhoto(Uri sourceUri) {
        // Copy file to internal storage to ensure persistence access
        executor.execute(() -> {
            File destFile = new File(getFilesDir(), "img_" + System.currentTimeMillis() + ".jpg");
            try (InputStream is = getContentResolver().openInputStream(sourceUri);
                    OutputStream os = new FileOutputStream(destFile)) {

                if (is == null)
                    return;

                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }

                String filePath = destFile.getAbsolutePath();

                // Update UI on main thread
                handler.post(() -> {
                    Photo newPhoto = new Photo(filePath);
                    currentAlbum.addPhoto(newPhoto);
                    adapter.notifyDataSetChanged();
                    updateEmptyView();
                    saveData();
                });

            } catch (IOException e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(AlbumContentActivity.this, "Failed to load image", Toast.LENGTH_SHORT)
                        .show());
            }
        });
    }

    private void saveData() {
        try {
            PersistenceManager.saveToDisk(this, userData);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPhotoClick(int position) {
        Intent intent = new Intent(this, DisplayPhotoActivity.class);
        intent.putExtra("albumIndex", albumIndex);
        intent.putExtra("photoIndex", position);
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Photo")
                .setMessage("Remove this photo from album?")
                .setPositiveButton("Remove", (dialog, which) -> {
                    currentAlbum.getPhotos().remove(position);
                    adapter.notifyItemRemoved(position);
                    // Also notify following items to update positions if necessary, but
                    // notifyDataSetChanged is safer for position syncing in simple apps
                    adapter.notifyDataSetChanged();
                    updateEmptyView();
                    saveData();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onMoveClick(int position) {
        // Show list of OTHER albums
        List<Album> otherAlbums = new ArrayList<>();
        List<String> albumNames = new ArrayList<>();

        for (Album a : userData.getAlbums()) {
            if (!a.equals(currentAlbum)) {
                otherAlbums.add(a);
                albumNames.add(a.getName());
            }
        }

        if (otherAlbums.isEmpty()) {
            Toast.makeText(this, "No other albums to move to.", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Move Photo to...")
                .setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, albumNames),
                        (dialog, which) -> {
                            Album targetAlbum = otherAlbums.get(which);
                            Photo photoToMove = currentAlbum.getPhotos().get(position);

                            targetAlbum.addPhoto(photoToMove);
                            currentAlbum.removePhoto(photoToMove);

                            adapter.notifyDataSetChanged();
                            updateEmptyView();
                            saveData();

                            Toast.makeText(this, "Moved to " + targetAlbum.getName(), Toast.LENGTH_SHORT).show();
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data if we came back from DisplayPhotoActivity (tags changed, or
        // logic changed)
        UserData reloaded = PersistenceManager.loadFromDisk(this);
        if (reloaded != null && albumIndex < reloaded.getAlbums().size()) {
            // In a real app we'd map IDs, here assuming index stability or single user
            userData = reloaded;
            currentAlbum = userData.getAlbums().get(albumIndex);
            adapter = new PhotosAdapter(currentAlbum.getPhotos(), this, this);
            recyclerView.setAdapter(adapter);
            updateEmptyView();
        }
    }
}
