package com.example.photos54;

import java.io.Serializable;
import java.util.Objects;

public class Tag implements Serializable {
    private static final long serialVersionUID = 1L;

    // Tag types
    public static final String TYPE_PERSON = "person";
    public static final String TYPE_LOCATION = "location";

    private String name;
    private String value;

    public Tag(String name, String value) {
        if (!name.equals(TYPE_PERSON) && !name.equals(TYPE_LOCATION)) {
            throw new IllegalArgumentException("Tag name must be 'person' or 'location'");
        }
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tag tag = (Tag) o;
        return Objects.equals(name, tag.name) && Objects.equals(value, tag.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, value);
    }

    @Override
    public String toString() {
        return name + ": " + value;
    }
}
