package com.example.photos54;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.List;

public class PhotosAdapter extends RecyclerView.Adapter<PhotosAdapter.PhotoViewHolder> {

    private List<Photo> photos;
    private OnPhotoClickListener listener;
    private OnPhotoActionListener actionListener;

    public interface OnPhotoClickListener {
        void onPhotoClick(int position);
    }

    public interface OnPhotoActionListener {
        void onDeleteClick(int position);

        void onMoveClick(int position);
    }

    public PhotosAdapter(List<Photo> photos, OnPhotoClickListener listener, OnPhotoActionListener actionListener) {
        this.photos = photos;
        this.listener = listener;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo_thumbnail, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        Photo photo = photos.get(position);

        // Load thumbnail using helper method
        Bitmap thumbnail = loadThumbnail(photo.getFilePath());
        if (thumbnail != null) {
            holder.imageView.setImageBitmap(thumbnail);
        } else {
            holder.imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null)
                listener.onPhotoClick(holder.getAdapterPosition());
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (actionListener != null)
                actionListener.onDeleteClick(holder.getAdapterPosition());
        });

        holder.btnMove.setOnClickListener(v -> {
            if (actionListener != null)
                actionListener.onMoveClick(holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return photos.size();
    }

    static class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        ImageButton btnMove;
        ImageButton btnDelete;

        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageViewThumbnail);
            btnMove = itemView.findViewById(R.id.buttonMovePhoto);
            btnDelete = itemView.findViewById(R.id.buttonDeletePhoto);
        }
    }

    // Helper method as requested
    public Bitmap loadThumbnail(String path) {
        File file = new File(path);
        if (!file.exists())
            return null;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        // Calculate inSampleSize
        // Target roughly 200x200 for thumbnails
        options.inSampleSize = calculateInSampleSize(options, 200, 200);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(path, options);
    }

    private int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}
