package com.example.photos54;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UserData implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Album> albums;

    public UserData() {
        this.albums = new ArrayList<>();
    }

    public List<Album> getAlbums() {
        return albums;
    }

    public void addAlbum(Album album) {
        albums.add(album); // Assuming uniqueness check is done at UI/Manager level
    }

    public void removeAlbum(Album album) {
        albums.remove(album);
    }
}
