package com.example.photos54;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SearchActivity extends AppCompatActivity implements PhotosAdapter.OnPhotoClickListener {

    private Spinner spinnerType1, spinnerType2;
    private AutoCompleteTextView autoComplete1, autoComplete2;
    private RadioGroup radioGroupLogic;
    private RecyclerView recyclerView;
    private PhotosAdapter adapter;
    private UserData userData;
    private List<Photo> searchResults = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        userData = PersistenceManager.loadFromDisk(this);

        spinnerType1 = findViewById(R.id.spinnerType1);
        spinnerType2 = findViewById(R.id.spinnerType2);
        autoComplete1 = findViewById(R.id.autoCompleteValue1);
        autoComplete2 = findViewById(R.id.autoCompleteValue2);
        radioGroupLogic = findViewById(R.id.radioGroupLogic);
        recyclerView = findViewById(R.id.recyclerViewResults);
        Button btnSearch = findViewById(R.id.btnSearch);

        setupUI();
        btnSearch.setOnClickListener(v -> performSearch());

        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new PhotosAdapter(searchResults, this, null);
        recyclerView.setAdapter(adapter);
    }

    private void setupUI() {
        String[] types = { Tag.TYPE_PERSON, Tag.TYPE_LOCATION };
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                types);
        spinnerType1.setAdapter(typeAdapter);
        spinnerType2.setAdapter(typeAdapter);

        // Collect all existing tag values for Autocomplete
        Set<String> allTagValues = new HashSet<>();
        for (Album album : userData.getAlbums()) {
            for (Photo photo : album.getPhotos()) {
                for (Tag tag : photo.getTags()) {
                    allTagValues.add(tag.getValue());
                }
            }
        }

        ArrayAdapter<String> autoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line,
                new ArrayList<>(allTagValues));
        autoComplete1.setAdapter(autoAdapter);
        autoComplete2.setAdapter(autoAdapter);
    }

    private void performSearch() {
        searchResults.clear();

        String type1 = spinnerType1.getSelectedItem().toString();
        String val1 = autoComplete1.getText().toString().trim().toLowerCase();

        String type2 = spinnerType2.getSelectedItem().toString();
        String val2 = autoComplete2.getText().toString().trim().toLowerCase();

        boolean isAnd = radioGroupLogic.getCheckedRadioButtonId() == R.id.radioAnd;

        if (val1.isEmpty() && val2.isEmpty()) {
            Toast.makeText(this, "Please enter at least one tag value", Toast.LENGTH_SHORT).show();
            adapter.notifyDataSetChanged();
            return;
        }

        for (Album album : userData.getAlbums()) {
            for (Photo photo : album.getPhotos()) {
                boolean match1 = !val1.isEmpty() && hasTag(photo, type1, val1);
                boolean match2 = !val2.isEmpty() && hasTag(photo, type2, val2);

                boolean finalMatch = false;

                if (!val1.isEmpty() && !val2.isEmpty()) {
                    finalMatch = isAnd ? (match1 && match2) : (match1 || match2);
                } else {
                    // If one is empty, we only care about the one that is present
                    finalMatch = match1 || match2;
                }

                if (finalMatch) {
                    searchResults.add(photo);
                }
            }
        }

        adapter.notifyDataSetChanged();
        if (searchResults.isEmpty()) {
            Toast.makeText(this, "No matches found", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasTag(Photo photo, String type, String valueFragment) {
        for (Tag tag : photo.getTags()) {
            if (tag.getName().equals(type) && tag.getValue().toLowerCase().startsWith(valueFragment)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onPhotoClick(int position) {
        Photo selected = searchResults.get(position);
        int albumIdx = -1;
        int photoIdx = -1;

        for (int a = 0; a < userData.getAlbums().size(); a++) {
            List<Photo> photos = userData.getAlbums().get(a).getPhotos();
            for (int p = 0; p < photos.size(); p++) {
                if (photos.get(p) == selected) {
                    albumIdx = a;
                    photoIdx = p;
                    break;
                }
            }
            if (albumIdx != -1)
                break;
        }

        if (albumIdx != -1) {
            Intent intent = new Intent(this, DisplayPhotoActivity.class);
            intent.putExtra("albumIndex", albumIdx);
            intent.putExtra("photoIndex", photoIdx);
            startActivity(intent);
        }
    }
}
