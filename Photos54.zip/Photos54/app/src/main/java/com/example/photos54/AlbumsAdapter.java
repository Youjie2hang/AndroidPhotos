package com.example.photos54;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AlbumsAdapter extends RecyclerView.Adapter<AlbumsAdapter.AlbumViewHolder> {

    private List<Album> albums;
    private OnAlbumClickListener onAlbumClickListener;
    private OnAlbumActionListener onAlbumActionListener;

    public interface OnAlbumClickListener {
        void onAlbumClick(int position);
    }

    public interface OnAlbumActionListener {
        void onDeleteClick(int position);

        void onRenameClick(int position);
    }

    public AlbumsAdapter(List<Album> albums, OnAlbumClickListener listener, OnAlbumActionListener actionListener) {
        this.albums = albums;
        this.onAlbumClickListener = listener;
        this.onAlbumActionListener = actionListener;
    }

    @NonNull
    @Override
    public AlbumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_album, parent, false);
        return new AlbumViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlbumViewHolder holder, int position) {
        Album album = albums.get(position);
        holder.textViewAlbumName.setText(album.getName());

        holder.itemView.setOnClickListener(v -> {
            if (onAlbumClickListener != null) {
                onAlbumClickListener.onAlbumClick(holder.getAdapterPosition());
            }
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (onAlbumActionListener != null) {
                onAlbumActionListener.onDeleteClick(holder.getAdapterPosition());
            }
        });

        holder.btnRename.setOnClickListener(v -> {
            if (onAlbumActionListener != null) {
                onAlbumActionListener.onRenameClick(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    static class AlbumViewHolder extends RecyclerView.ViewHolder {
        TextView textViewAlbumName;
        ImageButton btnDelete;
        ImageButton btnRename;

        public AlbumViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAlbumName = itemView.findViewById(R.id.textViewAlbumName);
            btnDelete = itemView.findViewById(R.id.buttonDeleteAlbum);
            btnRename = itemView.findViewById(R.id.buttonRenameAlbum);
        }
    }
}
