package com.example.photos54;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PersistenceManager {

    private static final String FILENAME = "photos.dat";

    public static void saveToDisk(Context context, UserData data) throws IOException {
        File file = new File(context.getFilesDir(), FILENAME);

        // Try-with-resources to ensure stream is closed
        try (FileOutputStream fos = new FileOutputStream(file);
                ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(data);
        }
    }

    public static UserData loadFromDisk(Context context) {
        File file = new File(context.getFilesDir(), FILENAME);
        if (!file.exists()) {
            return new UserData(); // Return empty data if file doesn't exist
        }

        try (FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis)) {
            return (UserData) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new UserData(); // Return empty data on error
        }
    }
}
