package com.example.photos54;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.IOException;

public class MainActivity extends AppCompatActivity
        implements AlbumsAdapter.OnAlbumClickListener, AlbumsAdapter.OnAlbumActionListener {

    private RecyclerView recyclerView;
    private AlbumsAdapter adapter;
    private UserData userData;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkPermissions();

        // Load data
        userData = PersistenceManager.loadFromDisk(this);

        recyclerView = findViewById(R.id.recyclerViewAlbums);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AlbumsAdapter(userData.getAlbums(), this, this);
        recyclerView.setAdapter(adapter);

        findViewById(R.id.btnOpenSearch).setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));

        FloatingActionButton fab = findViewById(R.id.fabAddAlbum);
        fab.setOnClickListener(view -> showCreateAlbumDialog());
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                        PERMISSION_REQUEST_CODE);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void showCreateAlbumDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Create New Album");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set listener to null initially to prevent auto-dismiss
        builder.setPositiveButton("Create", null);
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.show();

        // Override the positive button listener to handle validation
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String albumName = input.getText().toString().trim();
            if (albumName.isEmpty()) {
                return;
            }

            // Check for duplicates
            for (Album a : userData.getAlbums()) {
                if (a.getName().equalsIgnoreCase(albumName)) {
                    Toast.makeText(MainActivity.this, "Album name already exists", Toast.LENGTH_SHORT).show();
                    return; // Do not dismiss dialog
                }
            }

            createNewAlbum(albumName);
            dialog.dismiss();
        });
    }

    private void createNewAlbum(String name) {
        Album newAlbum = new Album(name);
        userData.addAlbum(newAlbum);
        adapter.notifyDataSetChanged();
        saveData();
    }

    private void deleteAlbum(int position) {
        userData.getAlbums().remove(position);
        adapter.notifyDataSetChanged();
        saveData();
    }

    private void renameAlbum(int position, String newName) {
        // Basic duplicate check excluding self
        for (Album a : userData.getAlbums()) {
            if (a.getName().equalsIgnoreCase(newName)) {
                return;
            }
        }

        Album album = userData.getAlbums().get(position);
        album.setName(newName);
        adapter.notifyDataSetChanged();
        saveData();
    }

    private void saveData() {
        try {
            PersistenceManager.saveToDisk(this, userData);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onAlbumClick(int position) {
        // Navigate to AlbumContentActivity
        Intent intent = new Intent(this, AlbumContentActivity.class);
        intent.putExtra("albumIndex", position);
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Album")
                .setMessage("Are you sure you want to delete this album?")
                .setPositiveButton("Delete", (dialog, which) -> deleteAlbum(position))
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onRenameClick(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rename Album");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(userData.getAlbums().get(position).getName());
        builder.setView(input);

        builder.setPositiveButton("Rename", (dialog, which) -> {
            String newName = input.getText().toString().trim();
            if (!newName.isEmpty()) {
                renameAlbum(position, newName);
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        UserData reloaded = PersistenceManager.loadFromDisk(this);
        if (reloaded != null) {
            userData.getAlbums().clear();
            userData.getAlbums().addAll(reloaded.getAlbums());
            adapter.notifyDataSetChanged();
        }
    }
}
