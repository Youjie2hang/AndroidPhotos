package com.example.photos54;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DisplayPhotoActivity extends AppCompatActivity {

    private ImageView imageView;
    private ListView listViewTags;
    private Button btnPrev, btnNext, btnAddTag, btnDeleteTag;

    private UserData userData;
    private Album currentAlbum;
    private Photo currentPhoto;
    private int albumIndex;
    private int photoIndex;

    private ArrayAdapter<Tag> tagsAdapter;
    private int selectedTagIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_photo);

        albumIndex = getIntent().getIntExtra("albumIndex", -1);
        photoIndex = getIntent().getIntExtra("photoIndex", -1);

        if (albumIndex == -1 || photoIndex == -1) {
            finish();
            return;
        }

        userData = PersistenceManager.loadFromDisk(this);
        if (albumIndex >= userData.getAlbums().size()) {
            finish();
            return;
        }
        currentAlbum = userData.getAlbums().get(albumIndex);

        imageView = findViewById(R.id.imageViewFull);
        listViewTags = findViewById(R.id.listViewTags);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnAddTag = findViewById(R.id.btnAddTag);
        btnDeleteTag = findViewById(R.id.btnDeleteTag);

        setupListeners();
        originalPhotoIndex = photoIndex; // Keep track if we need (for potential result intent, currently unsused)
        loadPhoto(photoIndex);
    }

    private int originalPhotoIndex;

    private void setupListeners() {
        btnPrev.setOnClickListener(v -> {
            if (photoIndex > 0) {
                photoIndex--;
                loadPhoto(photoIndex);
            }
        });

        btnNext.setOnClickListener(v -> {
            if (photoIndex < currentAlbum.getPhotos().size() - 1) {
                photoIndex++;
                loadPhoto(photoIndex);
            }
        });

        btnAddTag.setOnClickListener(v -> showAddTagDialog());

        listViewTags.setOnItemClickListener((parent, view, position, id) -> {
            selectedTagIndex = position;
            btnDeleteTag.setEnabled(true);
            view.setSelected(true); // Visual feedback
        });

        btnDeleteTag.setOnClickListener(v -> {
            if (selectedTagIndex != -1 && selectedTagIndex < currentPhoto.getTags().size()) {
                currentPhoto.removeTag(currentPhoto.getTags().get(selectedTagIndex));
                selectedTagIndex = -1;
                btnDeleteTag.setEnabled(false);
                updateTagsList();
                saveData();
            }
        });
    }

    private void loadPhoto(int index) {
        if (index < 0 || index >= currentAlbum.getPhotos().size())
            return;

        currentPhoto = currentAlbum.getPhotos().get(index);

        // Update Buttons
        btnPrev.setEnabled(index > 0);
        btnNext.setEnabled(index < currentAlbum.getPhotos().size() - 1);

        // Load Image
        // Use the helper we wrote in PhotosAdapter, or duplicate it.
        // Ideally we should move it to a Util class.
        // For now, to avoid modifying other files and causing conflicts, I'll inline a
        // safe decoder here.
        // Full screen display might need bigger size than thumbnail.
        Bitmap bmp = decodeSampledBitmapFromFile(currentPhoto.getFilePath(), 1080, 1920); // standard screen size
        if (bmp != null) {
            imageView.setImageBitmap(bmp);
        } else {
            imageView.setImageResource(android.R.drawable.ic_menu_report_image);
        }

        updateTagsList();
        selectedTagIndex = -1;
        btnDeleteTag.setEnabled(false);
    }

    private void updateTagsList() {
        // Create a copy list for adapter to avoid ConcurrentModification issues if any
        tagsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice,
                new ArrayList<>(currentPhoto.getTags()));
        listViewTags.setAdapter(tagsAdapter);
        // Restore selection if valid? No, simpler to reset on refresh.
        listViewTags.clearChoices();
    }

    private void showAddTagDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Tag");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        final Spinner typeSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[] { Tag.TYPE_PERSON, Tag.TYPE_LOCATION });
        typeSpinner.setAdapter(adapter);
        layout.addView(typeSpinner);

        final EditText valueInput = new EditText(this);
        valueInput.setHint("Tag Value (e.g. 'Alice')");
        layout.addView(valueInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String type = (String) typeSpinner.getSelectedItem();
            String value = valueInput.getText().toString().trim();

            if (!value.isEmpty()) {
                Tag newTag = new Tag(type, value);
                // Duplicate check
                if (currentPhoto.getTags().contains(newTag)) {
                    Toast.makeText(this, "Tag already exists", Toast.LENGTH_SHORT).show();
                } else {
                    currentPhoto.addTag(newTag);
                    updateTagsList();
                    saveData();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void saveData() {
        try {
            PersistenceManager.saveToDisk(this, userData);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper to avoid OOM
    private Bitmap decodeSampledBitmapFromFile(String path, int reqWidth, int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(path, options);
    }

    private int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }
}
